package com.warehouse.service;

import com.warehouse.util.JsonResponse;

public interface InventoryService extends BaseService<com.warehouse.beans.Inventory> {
    // ���ҵ�����еĲ���
    JsonResponse getByProduct(int productId);
    JsonResponse getByWarehouse(int warehouseId);
    JsonResponse getLowStockInventory();
    JsonResponse getInventorySummary(); // ������
    JsonResponse searchInventory(Integer productId, Integer warehouseId, Integer minQty, Integer maxQty);
    
    // ���������㡿���ܻ�λ�Ƽ�
    JsonResponse recommendLocation(int productId, int warehouseId, int quantity);
    
    // ������
    JsonResponse addStock(int productId, int locationId, int quantity, String operator);
    JsonResponse reduceStock(int productId, int locationId, int quantity, String operator);
    JsonResponse transferStock(int productId, int fromLocationId, int toLocationId, int quantity, String operator);
    
    // ���ͳ�Ʊ���
    JsonResponse getInventoryReport(String format); // format: "json", "excel", "csv"
}