package com.warehouse.service;

import com.warehouse.util.JsonResponse;

public interface InboundService extends BaseService<com.warehouse.beans.InboundOrder> {
    // ���ҵ�����з���
    JsonResponse getByProduct(int productId);
    JsonResponse getByLocation(int locationId);
    JsonResponse getByOperator(String operator);
    JsonResponse getRecentOrders(int limit);
    JsonResponse searchOrders(Integer productId, Integer locationId, String operator, String startDate, String endDate);
    
    // ������⣨���Ĺ��ܣ�
    JsonResponse smartInbound(int productId, int quantity, String operator);
    
    // ���ͳ��
    JsonResponse getInboundStats(String period); // daily, weekly, monthly
}