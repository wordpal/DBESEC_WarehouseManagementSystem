package com.warehouse.service.impl;

import com.warehouse.service.InventoryService;
import com.warehouse.beans.Inventory;
import com.warehouse.beans.Product;
import com.warehouse.beans.StorageLocation;
import com.warehouse.dao.InventoryDAO;
import com.warehouse.dao.ProductDAO;
import com.warehouse.dao.StorageLocationDAO;
import com.warehouse.dao.impl.InventoryDAOImpl;
import com.warehouse.dao.impl.ProductDAOImpl;
import com.warehouse.dao.impl.StorageLocationDAOImpl;
import com.warehouse.util.JsonResponse;
import java.util.*;

public class InventoryServiceImpl implements InventoryService {
    
    private InventoryDAO inventoryDAO;
    private ProductDAO productDAO;
    private StorageLocationDAO locationDAO;
    
    public InventoryServiceImpl() {
        this.inventoryDAO = new InventoryDAOImpl();
        this.productDAO = new ProductDAOImpl();
        this.locationDAO = new StorageLocationDAOImpl();
    }
    
    @Override
    public JsonResponse add(Inventory inventory) {
        try {
            // ������֤
            if (inventory.getProductId() <= 0) {
                return JsonResponse.badRequest("��ƷID��Ч");
            }
            if (inventory.getLocationId() <= 0) {
                return JsonResponse.badRequest("��λID��Ч");
            }
            if (inventory.getQuantity() < 0) {
                return JsonResponse.badRequest("�����������Ϊ����");
            }
            
            // ����Ʒ�ͻ�λ�Ƿ����
            Product product = productDAO.getById(inventory.getProductId());
            if (product == null) {
                return JsonResponse.notFound("��Ʒ������");
            }
            
            StorageLocation location = locationDAO.getById(inventory.getLocationId());
            if (location == null) {
                return JsonResponse.notFound("��λ������");
            }
            
            boolean success = inventoryDAO.insert(inventory);
            if (success) {
                // ���»�λ״̬Ϊռ��
                locationDAO.updateStatus(inventory.getLocationId(), 1);
                return JsonResponse.success("������ӳɹ�", inventory);
            } else {
                return JsonResponse.error("�������ʧ��");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return JsonResponse.error("ϵͳ����: " + e.getMessage());
        }
    }
    
    @Override
    public JsonResponse update(Inventory inventory) {
        try {
            // Inventory��ʹ�ø��������������߼�����
            if (inventory.getProductId() <= 0 || inventory.getLocationId() <= 0) {
                return JsonResponse.badRequest("��ƷID���λID��Ч");
            }
            
            boolean success = inventoryDAO.update(inventory);
            if (success) {
                // ������Ϊ0�����»�λ״̬Ϊ����
                if (inventory.getQuantity() == 0) {
                    locationDAO.updateStatus(inventory.getLocationId(), 0);
                }
                return JsonResponse.success("�����³ɹ�", inventory);
            } else {
                return JsonResponse.error("������ʧ��");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return JsonResponse.error("ϵͳ����: " + e.getMessage());
        }
    }
    
    @Override
    public JsonResponse delete(int id) {
        // Inventoryʹ�ø�������������ֱ���õ���IDɾ��
        return JsonResponse.error("����¼��Ҫʹ�ò�ƷID�ͻ�λIDɾ��");
    }
    
    @Override
    public JsonResponse getById(int id) {
        // Inventoryʹ�ø�������������ֱ���õ���ID��ѯ
        return JsonResponse.error("����¼��Ҫʹ�ò�ƷID�ͻ�λID��ѯ");
    }
    
    @Override
    public JsonResponse getAll() {
        try {
            List<Inventory> inventories = inventoryDAO.getAll();
            // ������Ʒ��Ϣ
            List<Map<String, Object>> result = new ArrayList<>();
            for (Inventory inv : inventories) {
                Map<String, Object> item = new HashMap<>();
                item.put("inventory", inv);
                
                Product product = productDAO.getById(inv.getProductId());
                if (product != null) {
                    item.put("productName", product.getProductName());
                    item.put("sku", product.getSku());
                    item.put("safetyStock", product.getSafetyStock());
                }
                
                result.add(item);
            }
            return JsonResponse.success(result);
        } catch (Exception e) {
            e.printStackTrace();
            return JsonResponse.error("ϵͳ����: " + e.getMessage());
        }
    }
    
    @Override
    public JsonResponse getByPage(int pageNum, int pageSize) {
        try {
            if (pageNum < 1) pageNum = 1;
            if (pageSize < 1 || pageSize > 100) pageSize = 10;
            
            List<Inventory> inventories = inventoryDAO.getByPage(pageNum, pageSize);
            int totalCount = inventoryDAO.getTotalCount();
            
            Map<String, Object> pageData = new HashMap<>();
            pageData.put("list", inventories);
            pageData.put("pageNum", pageNum);
            pageData.put("pageSize", pageSize);
            pageData.put("total", totalCount);
            pageData.put("totalPages", (int) Math.ceil((double) totalCount / pageSize));
            
            return JsonResponse.success(pageData);
        } catch (Exception e) {
            e.printStackTrace();
            return JsonResponse.error("ϵͳ����: " + e.getMessage());
        }
    }
    
    @Override
    public JsonResponse getByProduct(int productId) {
        try {
            List<Inventory> inventories = inventoryDAO.getByProduct(productId);
            
            // �����ܿ��
            int totalStock = 0;
            for (Inventory inv : inventories) {
                totalStock += inv.getQuantity();
            }
            
            Map<String, Object> result = new HashMap<>();
            result.put("inventories", inventories);
            result.put("totalStock", totalStock);
            
            // ���Ӳ�Ʒ��Ϣ
            Product product = productDAO.getById(productId);
            if (product != null) {
                result.put("productName", product.getProductName());
                result.put("safetyStock", product.getSafetyStock());
                result.put("isLowStock", totalStock <= product.getSafetyStock());
            }
            
            return JsonResponse.success(result);
        } catch (Exception e) {
            e.printStackTrace();
            return JsonResponse.error("ϵͳ����: " + e.getMessage());
        }
    }
    
    @Override
    public JsonResponse getByWarehouse(int warehouseId) {
        try {
            List<Inventory> inventories = inventoryDAO.getByWarehouse(warehouseId);
            
            // ����Ʒ����ͳ��
            Map<Integer, Integer> productStock = new HashMap<>();
            int totalValue = 0;
            
            for (Inventory inv : inventories) {
                productStock.put(inv.getProductId(), 
                    productStock.getOrDefault(inv.getProductId(), 0) + inv.getQuantity());
            }
            
            Map<String, Object> result = new HashMap<>();
            result.put("inventories", inventories);
            result.put("productCount", productStock.size());
            result.put("totalItems", inventories.size());
            result.put("productDistribution", productStock);
            
            return JsonResponse.success(result);
        } catch (Exception e) {
            e.printStackTrace();
            return JsonResponse.error("ϵͳ����: " + e.getMessage());
        }
    }
    
    @Override
    public JsonResponse getLowStockInventory() {
        try {
            List<Inventory> lowStockItems = inventoryDAO.getLowStockInventory();
            
            // ���Ӳ�Ʒ��Ϣ�Ϳ��״̬
            List<Map<String, Object>> result = new ArrayList<>();
            for (Inventory inv : lowStockItems) {
                Map<String, Object> item = new HashMap<>();
                item.put("inventory", inv);
                
                Product product = productDAO.getById(inv.getProductId());
                if (product != null) {
                    item.put("productName", product.getProductName());
                    item.put("sku", product.getSku());
                    item.put("safetyStock", product.getSafetyStock());
                    item.put("stockRatio", (double) inv.getQuantity() / product.getSafetyStock());
                    
                    // Ԥ������
                    if (inv.getQuantity() == 0) {
                        item.put("alertLevel", "red");      // ��ɫԤ�����޿��
                    } else if (inv.getQuantity() <= product.getSafetyStock() * 0.3) {
                        item.put("alertLevel", "orange");   // ��ɫԤ����������ز���
                    } else {
                        item.put("alertLevel", "yellow");   // ��ɫԤ������治��
                    }
                }
                
                result.add(item);
            }
            
            return JsonResponse.success(result);
        } catch (Exception e) {
            e.printStackTrace();
            return JsonResponse.error("ϵͳ����: " + e.getMessage());
        }
    }
    
    @Override
    public JsonResponse getInventorySummary() {
        try {
            List<Inventory> allInventory = inventoryDAO.getAll();
            
            // ͳ����Ϣ
            int totalProducts = 0;
            int totalQuantity = 0;
            int lowStockCount = 0;
            int zeroStockCount = 0;
            
            Set<Integer> productSet = new HashSet<>();
            for (Inventory inv : allInventory) {
                productSet.add(inv.getProductId());
                totalQuantity += inv.getQuantity();
                
                if (inv.getQuantity() == 0) {
                    zeroStockCount++;
                }
            }
            totalProducts = productSet.size();
            
            // �Ϳ��ͳ��
            List<Inventory> lowStock = inventoryDAO.getLowStockInventory();
            lowStockCount = lowStock.size();
            
            Map<String, Object> summary = new HashMap<>();
            summary.put("totalProducts", totalProducts);
            summary.put("totalQuantity", totalQuantity);
            summary.put("lowStockCount", lowStockCount);
            summary.put("zeroStockCount", zeroStockCount);
            summary.put("inventoryValue", "������"); // ��Ҫ�۸���Ϣ
            
            return JsonResponse.success(summary);
        } catch (Exception e) {
            e.printStackTrace();
            return JsonResponse.error("ϵͳ����: " + e.getMessage());
        }
    }
    
    @Override
    public JsonResponse searchInventory(Integer productId, Integer warehouseId, Integer minQty, Integer maxQty) {
        try {
            List<Inventory> results = inventoryDAO.searchWithConditions(productId, warehouseId, null, minQty, maxQty);
            return JsonResponse.success(results);
        } catch (Exception e) {
            e.printStackTrace();
            return JsonResponse.error("ϵͳ����: " + e.getMessage());
        }
    }
    
    @Override
    public JsonResponse recommendLocation(int productId, int warehouseId, int quantity) {
        try {
            // ���������㡿���ܻ�λ�Ƽ��㷨
            Product product = productDAO.getById(productId);
            if (product == null) {
                return JsonResponse.notFound("��Ʒ������");
            }
            
            // 1. ��ȡָ���ֿ�����п��л�λ
            List<StorageLocation> availableLocations = locationDAO.getAvailableLocations(warehouseId);
            if (availableLocations.isEmpty()) {
                return JsonResponse.error("�òֿ�û�п��л�λ");
            }
            
            // 2. �����Ƽ��㷨���򻯰棩
            // ����1������ѡ��ͬһ��Ʒ���еĻ�λ�����д�ţ�
            List<Inventory> existingInventory = inventoryDAO.getByProduct(productId);
            Set<Integer> existingLocations = new HashSet<>();
            for (Inventory inv : existingInventory) {
                existingLocations.add(inv.getLocationId());
            }
            
            // ����2�����ǲ�Ʒ�ߴ磨����гߴ���Ϣ��
            boolean hasDimensions = product.getLength() != null && product.getWidth() != null && product.getHeight() != null;
            
            // ����3������λ�������򣨼򵥲��ԣ�
            List<Map<String, Object>> recommendations = new ArrayList<>();
            
            for (StorageLocation location : availableLocations) {
                Map<String, Object> recommendation = new HashMap<>();
                recommendation.put("locationId", location.getLocationId());
                recommendation.put("locationCode", location.getLocationCode());
                recommendation.put("score", 0);
                
                // ���ֹ���
                int score = 0;
                
                // ����1��ͬһ��Ʒ���л�λ�ӷ�
                if (existingLocations.contains(location.getLocationId())) {
                    score += 30;
                    recommendation.put("reason", "ͬһ��Ʒ���ڴ˻�λ���");
                }
                
                // ����2����λ�������򣨼򵥲��ԣ�
                score += 10;
                
                recommendation.put("score", score);
                recommendations.add(recommendation);
            }
            
            // ����������
            recommendations.sort((a, b) -> {
                int scoreA = (int) a.get("score");
                int scoreB = (int) b.get("score");
                return Integer.compare(scoreB, scoreA); // ����
            });
            
            // ֻ����ǰ3���Ƽ�
            if (recommendations.size() > 3) {
                recommendations = recommendations.subList(0, 3);
            }
            
            Map<String, Object> result = new HashMap<>();
            result.put("productId", productId);
            result.put("productName", product.getProductName());
            result.put("warehouseId", warehouseId);
            result.put("quantity", quantity);
            result.put("recommendations", recommendations);
            
            return JsonResponse.success("���ܻ�λ�Ƽ����", result);
        } catch (Exception e) {
            e.printStackTrace();
            return JsonResponse.error("ϵͳ����: " + e.getMessage());
        }
    }
    
    @Override
    public JsonResponse addStock(int productId, int locationId, int quantity, String operator) {
        try {
            if (quantity <= 0) {
                return JsonResponse.badRequest("��������������0");
            }
            
            boolean success = inventoryDAO.addQuantity(productId, locationId, quantity);
            if (success) {
                // ���»�λ״̬
                locationDAO.updateStatus(locationId, 1);
                
                // ��¼�����־��������Ե���InboundOrderDAO��
                Map<String, Object> result = new HashMap<>();
                result.put("productId", productId);
                result.put("locationId", locationId);
                result.put("quantity", quantity);
                result.put("operator", operator);
                result.put("message", "���ɹ�");
                
                return JsonResponse.success(result);
            } else {
                return JsonResponse.error("���ʧ��");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return JsonResponse.error("ϵͳ����: " + e.getMessage());
        }
    }
    
    @Override
    public JsonResponse reduceStock(int productId, int locationId, int quantity, String operator) {
        try {
            if (quantity <= 0) {
                return JsonResponse.badRequest("���������������0");
            }
            
            // ������Ƿ��㹻
            Inventory current = inventoryDAO.getByProductAndLocation(productId, locationId);
            if (current == null || current.getQuantity() < quantity) {
                return JsonResponse.error("��治��");
            }
            
            boolean success = inventoryDAO.reduceQuantity(productId, locationId, quantity);
            if (success) {
                // ������Ϊ0�����»�λ״̬
                int newQuantity = current.getQuantity() - quantity;
                if (newQuantity == 0) {
                    locationDAO.updateStatus(locationId, 0);
                }
                
                // ��¼������־
                Map<String, Object> result = new HashMap<>();
                result.put("productId", productId);
                result.put("locationId", locationId);
                result.put("quantity", quantity);
                result.put("remaining", newQuantity);
                result.put("operator", operator);
                result.put("message", "����ɹ�");
                
                return JsonResponse.success(result);
            } else {
                return JsonResponse.error("����ʧ��");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return JsonResponse.error("ϵͳ����: " + e.getMessage());
        }
    }
    
    @Override
    public JsonResponse transferStock(int productId, int fromLocationId, int toLocationId, int quantity, String operator) {
        try {
            // 1. ��ԭ��λ���ٿ��
            JsonResponse reduceResult = reduceStock(productId, fromLocationId, quantity, operator);
            if (reduceResult.getCode() != 200) {
                return reduceResult;
            }
            
            // 2. ��Ŀ���λ���ӿ��
            JsonResponse addResult = addStock(productId, toLocationId, quantity, operator);
            if (addResult.getCode() != 200) {
                // �������ʧ�ܣ����Իָ�ԭ���
                addStock(productId, fromLocationId, quantity, "system-recovery");
                return JsonResponse.error("���ת��ʧ�ܣ��ѻָ�ԭ���");
            }
            
            Map<String, Object> result = new HashMap<>();
            result.put("productId", productId);
            result.put("fromLocationId", fromLocationId);
            result.put("toLocationId", toLocationId);
            result.put("quantity", quantity);
            result.put("operator", operator);
            result.put("message", "���ת�Ƴɹ�");
            
            return JsonResponse.success(result);
        } catch (Exception e) {
            e.printStackTrace();
            return JsonResponse.error("ϵͳ����: " + e.getMessage());
        }
    }
    
    @Override
    public JsonResponse getInventoryReport(String format) {
        // �򻯵ı�������
        try {
            List<Inventory> allInventory = inventoryDAO.getAll();
            
            if ("json".equalsIgnoreCase(format)) {
                return JsonResponse.success(allInventory);
            } else if ("excel".equalsIgnoreCase(format) || "csv".equalsIgnoreCase(format)) {
                // �����������Excel��CSV�ļ�
                Map<String, Object> report = new HashMap<>();
                report.put("format", format);
                report.put("recordCount", allInventory.size());
                report.put("message", format.toUpperCase() + "�������ɹ��ܴ�ʵ��");
                return JsonResponse.success(report);
            } else {
                return JsonResponse.badRequest("��֧�ֵı�����ʽ��֧��: json, excel, csv");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return JsonResponse.error("ϵͳ����: " + e.getMessage());
        }
    }
}