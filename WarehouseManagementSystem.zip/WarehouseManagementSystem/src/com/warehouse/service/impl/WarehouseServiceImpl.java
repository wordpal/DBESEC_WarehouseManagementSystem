package com.warehouse.service.impl;

import com.warehouse.service.WarehouseService;
import com.warehouse.beans.Warehouse;
import com.warehouse.dao.WarehouseDAO;
import com.warehouse.dao.impl.WarehouseDAOImpl;
import com.warehouse.util.JsonResponse;
import java.util.List;

public class WarehouseServiceImpl implements WarehouseService {
    
    private WarehouseDAO warehouseDAO;
    
    public WarehouseServiceImpl() {
        this.warehouseDAO = new WarehouseDAOImpl();
    }
    
    @Override
    public JsonResponse add(Warehouse warehouse) {
        try {
            // ������֤
            if (warehouse.getWarehouseCode() == null || warehouse.getWarehouseCode().trim().isEmpty()) {
                return JsonResponse.badRequest("�ֿ���벻��Ϊ��");
            }
            if (warehouse.getWarehouseName() == null || warehouse.getWarehouseName().trim().isEmpty()) {
                return JsonResponse.badRequest("�ֿ����Ʋ���Ϊ��");
            }
            
            // �������Ƿ��Ѵ���
            Warehouse existing = warehouseDAO.getByCode(warehouse.getWarehouseCode());
            if (existing != null) {
                return JsonResponse.badRequest("�ֿ�����Ѵ���");
            }
            
            boolean success = warehouseDAO.insert(warehouse);
            if (success) {
                return JsonResponse.success("�ֿ����ӳɹ�", warehouse);
            } else {
                return JsonResponse.error("�ֿ�����ʧ��");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return JsonResponse.error("ϵͳ����: " + e.getMessage());
        }
    }
    
    @Override
    public JsonResponse update(Warehouse warehouse) {
        try {
            // ������֤
            if (warehouse.getWarehouseId() <= 0) {
                return JsonResponse.badRequest("�ֿ�ID��Ч");
            }
            if (warehouse.getWarehouseCode() == null || warehouse.getWarehouseCode().trim().isEmpty()) {
                return JsonResponse.badRequest("�ֿ���벻��Ϊ��");
            }
            
            // �������Ƿ������ֿ�ʹ��
            Warehouse existingByCode = warehouseDAO.getByCode(warehouse.getWarehouseCode());
            if (existingByCode != null && existingByCode.getWarehouseId() != warehouse.getWarehouseId()) {
                return JsonResponse.badRequest("�ֿ�����ѱ������ֿ�ʹ��");
            }
            
            boolean success = warehouseDAO.update(warehouse);
            if (success) {
                return JsonResponse.success("�ֿ���³ɹ�", warehouse);
            } else {
                return JsonResponse.error("�ֿ����ʧ��");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return JsonResponse.error("ϵͳ����: " + e.getMessage());
        }
    }
    
    @Override
    public JsonResponse delete(int warehouseId) {
        try {
            // ���ֿ��Ƿ����
            Warehouse warehouse = warehouseDAO.getById(warehouseId);
            if (warehouse == null) {
                return JsonResponse.notFound("�ֿⲻ����");
            }
            
            // �߼�ɾ������Ϊ�ǻ�Ծ��
            boolean success = warehouseDAO.delete(warehouseId);
            if (success) {
                return JsonResponse.success("�ֿ�ɾ���ɹ�");
            } else {
                return JsonResponse.error("�ֿ�ɾ��ʧ��");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return JsonResponse.error("ϵͳ����: " + e.getMessage());
        }
    }
    
    @Override
    public JsonResponse getById(int warehouseId) {
        try {
            Warehouse warehouse = warehouseDAO.getById(warehouseId);
            if (warehouse != null) {
                return JsonResponse.success(warehouse);
            } else {
                return JsonResponse.notFound("�ֿⲻ����");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return JsonResponse.error("ϵͳ����: " + e.getMessage());
        }
    }
    
    @Override
    public JsonResponse getAll() {
        try {
            List<Warehouse> warehouses = warehouseDAO.getAll();
            return JsonResponse.success(warehouses);
        } catch (Exception e) {
            e.printStackTrace();
            return JsonResponse.error("ϵͳ����: " + e.getMessage());
        }
    }
    
    @Override
    public JsonResponse getByPage(int pageNum, int pageSize) {
        try {
            // ������֤
            if (pageNum < 1) pageNum = 1;
            if (pageSize < 1 || pageSize > 100) pageSize = 10;
            
            List<Warehouse> warehouses = warehouseDAO.getByPage(pageNum, pageSize);
            int totalCount = warehouseDAO.getTotalCount();
            
            // ������ҳ��Ӧ
            java.util.Map<String, Object> pageData = new java.util.HashMap<>();
            pageData.put("list", warehouses);
            pageData.put("pageNum", pageNum);
            pageData.put("pageSize", pageSize);
            pageData.put("total", totalCount);
            pageData.put("totalPages", (int) Math.ceil((double) totalCount / pageSize));
            
            return JsonResponse.success(pageData);
        } catch (Exception e) {
            e.printStackTrace();
            return JsonResponse.error("ϵͳ����: " + e.getMessage());
        }
    }
    
    @Override
    public JsonResponse getByCode(String warehouseCode) {
        try {
            Warehouse warehouse = warehouseDAO.getByCode(warehouseCode);
            if (warehouse != null) {
                return JsonResponse.success(warehouse);
            } else {
                return JsonResponse.notFound("�ֿⲻ����");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return JsonResponse.error("ϵͳ����: " + e.getMessage());
        }
    }
    
    @Override
    public JsonResponse getActiveWarehouses() {
        try {
            List<Warehouse> warehouses = warehouseDAO.getActiveWarehouses();
            return JsonResponse.success(warehouses);
        } catch (Exception e) {
            e.printStackTrace();
            return JsonResponse.error("ϵͳ����: " + e.getMessage());
        }
    }
    
    @Override
    public JsonResponse getByCountry(String country) {
        try {
            if (country == null || country.trim().isEmpty()) {
                return JsonResponse.badRequest("���Ҳ���Ϊ��");
            }
            
            List<Warehouse> warehouses = warehouseDAO.getByCountry(country);
            return JsonResponse.success(warehouses);
        } catch (Exception e) {
            e.printStackTrace();
            return JsonResponse.error("ϵͳ����: " + e.getMessage());
        }
    }
    
    @Override
    public JsonResponse deactivateWarehouse(int warehouseId) {
        try {
            boolean success = warehouseDAO.deactivateWarehouse(warehouseId);
            if (success) {
                return JsonResponse.success("�ֿ���ͣ��");
            } else {
                return JsonResponse.error("�ֿ�ͣ��ʧ��");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return JsonResponse.error("ϵͳ����: " + e.getMessage());
        }
    }
    
    @Override
    public JsonResponse activateWarehouse(int warehouseId) {
        try {
            boolean success = warehouseDAO.activateWarehouse(warehouseId);
            if (success) {
                return JsonResponse.success("�ֿ�������");
            } else {
                return JsonResponse.error("�ֿ�����ʧ��");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return JsonResponse.error("ϵͳ����: " + e.getMessage());
        }
    }
    
    @Override
    public JsonResponse getWarehouseStats() {
        try {
            List<Warehouse> allWarehouses = warehouseDAO.getAll();
            List<Warehouse> activeWarehouses = warehouseDAO.getActiveWarehouses();
            
            // ������ͳ��
            java.util.Map<String, Integer> countryStats = new java.util.HashMap<>();
            for (Warehouse wh : allWarehouses) {
                String country = wh.getCountry();
                countryStats.put(country, countryStats.getOrDefault(country, 0) + 1);
            }
            
            java.util.Map<String, Object> stats = new java.util.HashMap<>();
            stats.put("totalWarehouses", allWarehouses.size());
            stats.put("activeWarehouses", activeWarehouses.size());
            stats.put("inactiveWarehouses", allWarehouses.size() - activeWarehouses.size());
            stats.put("countryDistribution", countryStats);
            
            return JsonResponse.success(stats);
        } catch (Exception e) {
            e.printStackTrace();
            return JsonResponse.error("ϵͳ����: " + e.getMessage());
        }
    }
}