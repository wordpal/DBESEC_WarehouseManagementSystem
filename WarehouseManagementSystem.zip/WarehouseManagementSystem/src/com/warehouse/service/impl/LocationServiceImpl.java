package com.warehouse.service.impl;

import com.warehouse.service.LocationService;
import com.warehouse.beans.StorageLocation;
import com.warehouse.dao.StorageLocationDAO;
import com.warehouse.dao.impl.StorageLocationDAOImpl;
import com.warehouse.util.JsonResponse;
import java.util.List;

public class LocationServiceImpl implements LocationService {
    
    private StorageLocationDAO locationDAO;
    
    public LocationServiceImpl() {
        this.locationDAO = new StorageLocationDAOImpl();
    }
    
    @Override
    public JsonResponse add(StorageLocation location) {
        try {
            // ��֤����
            if (location.getLocationCode() == null || location.getLocationCode().trim().isEmpty()) {
                return JsonResponse.badRequest("��λ���벻��Ϊ��");
            }
            if (location.getWarehouseId() <= 0) {
                return JsonResponse.badRequest("�ֿ�ID��Ч");
            }
            
            // �������Ƿ��ظ�
            StorageLocation existing = locationDAO.getByCode(location.getLocationCode());
            if (existing != null) {
                return JsonResponse.badRequest("��λ�����Ѵ���");
            }
            
            boolean success = locationDAO.insert(location);
            if (success) {
                return JsonResponse.success("��λ���ӳɹ�", location);
            } else {
                return JsonResponse.error("��λ����ʧ��");
            }
        } catch (Exception e) {
            return JsonResponse.error("ϵͳ����: " + e.getMessage());
        }
    }
    
    @Override
    public JsonResponse update(StorageLocation location) {
        try {
            if (location.getLocationId() <= 0) {
                return JsonResponse.badRequest("��λID��Ч");
            }
            
            boolean success = locationDAO.update(location);
            if (success) {
                return JsonResponse.success("��λ���³ɹ�", location);
            } else {
                return JsonResponse.error("��λ����ʧ��");
            }
        } catch (Exception e) {
            return JsonResponse.error("ϵͳ����: " + e.getMessage());
        }
    }
    
    @Override
    public JsonResponse delete(int locationId) {
        try {
            // �ȼ���Ƿ��п��
            StorageLocation location = locationDAO.getById(locationId);
            if (location == null) {
                return JsonResponse.notFound("��λ������");
            }
            
            // ��ʵ��ϵͳ�У�����Ӧ�ü���λ�Ƿ��п��
            // ����п�治��ɾ��
            
            boolean success = locationDAO.delete(locationId);
            if (success) {
                return JsonResponse.success("��λɾ���ɹ�");
            } else {
                return JsonResponse.error("��λɾ��ʧ�ܣ������п�棩");
            }
        } catch (Exception e) {
            return JsonResponse.error("ϵͳ����: " + e.getMessage());
        }
    }
    
    @Override
    public JsonResponse getById(int locationId) {
        try {
            StorageLocation location = locationDAO.getById(locationId);
            if (location != null) {
                return JsonResponse.success(location);
            } else {
                return JsonResponse.notFound("��λ������");
            }
        } catch (Exception e) {
            return JsonResponse.error("ϵͳ����: " + e.getMessage());
        }
    }
    
    @Override
    public JsonResponse getAll() {
        try {
            List<StorageLocation> locations = locationDAO.getAll();
            return JsonResponse.success(locations);
        } catch (Exception e) {
            return JsonResponse.error("ϵͳ����: " + e.getMessage());
        }
    }
    
    @Override
    public JsonResponse getByPage(int pageNum, int pageSize) {
        try {
            if (pageNum < 1) pageNum = 1;
            if (pageSize < 1 || pageSize > 100) pageSize = 10;
            
            List<StorageLocation> locations = locationDAO.getByPage(pageNum, pageSize);
            int totalCount = locationDAO.getTotalCount();
            
            java.util.Map<String, Object> pageData = new java.util.HashMap<>();
            pageData.put("list", locations);
            pageData.put("pageNum", pageNum);
            pageData.put("pageSize", pageSize);
            pageData.put("total", totalCount);
            pageData.put("totalPages", (int) Math.ceil((double) totalCount / pageSize));
            
            return JsonResponse.success(pageData);
        } catch (Exception e) {
            return JsonResponse.error("ϵͳ����: " + e.getMessage());
        }
    }
    
    @Override
    public JsonResponse getByWarehouse(int warehouseId) {
        try {
            if (warehouseId <= 0) {
                return JsonResponse.badRequest("�ֿ�ID��Ч");
            }
            
            List<StorageLocation> locations = locationDAO.getByWarehouse(warehouseId);
            return JsonResponse.success(locations);
        } catch (Exception e) {
            return JsonResponse.error("ϵͳ����: " + e.getMessage());
        }
    }
    
    @Override
    public JsonResponse getAvailableLocations(int warehouseId) {
        try {
            if (warehouseId <= 0) {
                return JsonResponse.badRequest("�ֿ�ID��Ч");
            }
            
            List<StorageLocation> locations = locationDAO.getAvailableLocations(warehouseId);
            return JsonResponse.success(locations);
        } catch (Exception e) {
            return JsonResponse.error("ϵͳ����: " + e.getMessage());
        }
    }
    
    @Override
    public JsonResponse getOccupiedLocations(int warehouseId) {
        try {
            if (warehouseId <= 0) {
                return JsonResponse.badRequest("�ֿ�ID��Ч");
            }
            
            List<StorageLocation> locations = locationDAO.getOccupiedLocations(warehouseId);
            return JsonResponse.success(locations);
        } catch (Exception e) {
            return JsonResponse.error("ϵͳ����: " + e.getMessage());
        }
    }
    
    @Override
    public JsonResponse updateStatus(int locationId, int status) {
        try {
            if (locationId <= 0) {
                return JsonResponse.badRequest("��λID��Ч");
            }
            if (status != 0 && status != 1) {
                return JsonResponse.badRequest("״ֵ̬��Ч��0-���У�1-ռ�ã�");
            }
            
            boolean success = locationDAO.updateStatus(locationId, status);
            if (success) {
                String statusText = status == 0 ? "����" : "ռ��";
                return JsonResponse.success("��λ״̬�Ѹ���Ϊ��" + statusText);
            } else {
                return JsonResponse.error("��λ״̬����ʧ��");
            }
        } catch (Exception e) {
            return JsonResponse.error("ϵͳ����: " + e.getMessage());
        }
    }
    
    @Override
    public JsonResponse getByCode(String locationCode) {
        try {
            if (locationCode == null || locationCode.trim().isEmpty()) {
                return JsonResponse.badRequest("��λ���벻��Ϊ��");
            }
            
            StorageLocation location = locationDAO.getByCode(locationCode);
            if (location != null) {
                return JsonResponse.success(location);
            } else {
                return JsonResponse.notFound("��λ������");
            }
        } catch (Exception e) {
            return JsonResponse.error("ϵͳ����: " + e.getMessage());
        }
    }
}