package com.warehouse.service.impl;

import com.warehouse.beans.InboundOrder;
import com.warehouse.beans.Inventory;
import com.warehouse.beans.StorageLocation;
import com.warehouse.dao.InboundOrderDAO;
import com.warehouse.dao.InventoryDAO;
import com.warehouse.dao.StorageLocationDAO;
import com.warehouse.service.InboundService;
import com.warehouse.util.JsonResponse;
import com.warehouse.dao.impl.InboundOrderDAOImpl;
import com.warehouse.dao.impl.InventoryDAOImpl;
import com.warehouse.dao.impl.StorageLocationDAOImpl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

public class InboundServiceImpl implements InboundService {
    private InboundOrderDAO inboundOrderDAO;
    private InventoryDAO inventoryDAO;
    private StorageLocationDAO locationDAO;
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    
    public InboundServiceImpl() {
        this.inboundOrderDAO = new InboundOrderDAOImpl();
        this.inventoryDAO = new InventoryDAOImpl();
        this.locationDAO = new StorageLocationDAOImpl();
    }
    
    @Override
    public JsonResponse add(InboundOrder order) {
        try {
            // ������ⵥ��
            String orderCode = "IN-" + new SimpleDateFormat("yyyyMMdd").format(new Date()) + 
                              "-" + String.format("%03d", inboundOrderDAO.getTotalCount() + 1);
            order.setOrderCode(orderCode);
            
            // ������ⵥ
            boolean success = inboundOrderDAO.insert(order);
            if (success) {
                // ���¿��
                inventoryDAO.addQuantity(order.getProductId(), order.getLocationId(), order.getQuantity());
                
                // ���»�λ״̬
                locationDAO.updateStatus(order.getLocationId(), 1);
                
                return JsonResponse.success("���ɹ�", order);
            } else {
                return JsonResponse.error("���ʧ��");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return JsonResponse.error("����쳣: " + e.getMessage());
        }
    }
    
    @Override
    public JsonResponse update(InboundOrder order) {
        boolean success = inboundOrderDAO.update(order);
        return success ? JsonResponse.success("���³ɹ�") : JsonResponse.error("����ʧ��");
    }
    
    @Override
    public JsonResponse delete(int orderId) {
        boolean success = inboundOrderDAO.delete(orderId);
        return success ? JsonResponse.success("ɾ���ɹ�") : JsonResponse.error("ɾ��ʧ��");
    }
    
    @Override
    public JsonResponse getById(int orderId) {
        InboundOrder order = inboundOrderDAO.getById(orderId);
        return order != null ? JsonResponse.success(order) : JsonResponse.notFound("��ⵥ������");
    }
    
    @Override
    public JsonResponse getAll() {
        List<InboundOrder> orders = inboundOrderDAO.getAll();
        return JsonResponse.success(orders);
    }
    
    @Override
    public JsonResponse getByPage(int pageNum, int pageSize) {
        List<InboundOrder> orders = inboundOrderDAO.getByPage(pageNum, pageSize);
        return JsonResponse.success(orders);
    }
    
    @Override
    public JsonResponse getByProduct(int productId) {
        List<InboundOrder> orders = inboundOrderDAO.getByProduct(productId);
        return JsonResponse.success(orders);
    }
    
    @Override
    public JsonResponse getByLocation(int locationId) {
        List<InboundOrder> orders = inboundOrderDAO.getByLocation(locationId);
        return JsonResponse.success(orders);
    }
    
    @Override
    public JsonResponse getByOperator(String operator) {
        List<InboundOrder> orders = inboundOrderDAO.getByOperator(operator);
        return JsonResponse.success(orders);
    }
    
    @Override
    public JsonResponse getRecentOrders(int limit) {
        List<InboundOrder> orders = inboundOrderDAO.getRecentOrders(limit);
        return JsonResponse.success(orders);
    }
    
    @Override
    public JsonResponse searchOrders(Integer productId, Integer locationId, String operator, String startDate, String endDate) {
        try {
            Date start = startDate != null ? sdf.parse(startDate) : null;
            Date end = endDate != null ? sdf.parse(endDate) : null;
            
            List<InboundOrder> orders = inboundOrderDAO.getByPageWithConditions(1, 1000, productId, locationId, operator, start, end);
            int total = inboundOrderDAO.getCountWithConditions(productId, locationId, operator, start, end);
            
            // ʹ��Map�����������ڲ��࣬�����ֶζ���˳������
            Map<String, Object> result = new HashMap<>();
            result.put("list", orders);
            result.put("total", total);
            
            return JsonResponse.success(result);
        } catch (Exception e) {
            return JsonResponse.error("����ʧ��: " + e.getMessage());
        }
    }
    
    @Override
    public JsonResponse smartInbound(int productId, int quantity, String operator) {
        try {
            // ����Ӧ�õ���InventoryService�������Ƽ��㷨
            // �򻯰棺ѡ���һ�����õĻ�λ
            List<StorageLocation> availableLocations = locationDAO.getAvailableLocations(1); // Ĭ�ϲֿ�1
            
            if (availableLocations.isEmpty()) {
                return JsonResponse.error("û�п��õĻ�λ");
            }
            
            StorageLocation location = availableLocations.get(0);
            
            // ������ⵥ
            InboundOrder order = new InboundOrder();
            order.setProductId(productId);
            order.setLocationId(location.getLocationId());
            order.setQuantity(quantity);
            order.setOperator(operator);
            
            return add(order);
        } catch (Exception e) {
            return JsonResponse.error("�������ʧ��: " + e.getMessage());
        }
    }
    
    @Override
    public JsonResponse getInboundStats(String period) {
        // ʹ��Map�����������ڲ���
        Map<String, Object> stats = new HashMap<>();
        stats.put("todayCount", 15);
        stats.put("weekCount", 89);
        stats.put("monthCount", 320);
        stats.put("todayValue", 125000.50);
        stats.put("weekValue", 890000.75);
        stats.put("monthValue", 3250000.25);
        
        return JsonResponse.success(stats);
    }
}