package com.warehouse.dao;

import java.util.List;

public interface BaseDAO<T> {
    // ����CRUD����
    boolean insert(T obj);
    boolean update(T obj);
    boolean delete(int id);
    T getById(int id);
    List<T> getAll();
    
    // ��ҳ��ѯ
    List<T> getByPage(int pageNum, int pageSize);
    int getTotalCount();
}