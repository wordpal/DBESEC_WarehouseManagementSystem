package com.warehouse.dao;

import com.warehouse.beans.Inventory;
import java.util.List;

public interface InventoryDAO extends BaseDAO<Inventory> {
    // ������еĲ���
    Inventory getByProductAndLocation(int productId, int locationId);
    List<Inventory> getByProduct(int productId);
    List<Inventory> getByLocation(int locationId);
    List<Inventory> getByWarehouse(int warehouseId);
    List<Inventory> getLowStockInventory();  // �Ϳ�棨���ܰ�ȫ��棩
    List<Inventory> getEmptyInventory();     // ����
    boolean updateQuantity(int productId, int locationId, int quantity);
    boolean addQuantity(int productId, int locationId, int quantity);  // ���ӿ��
    boolean reduceQuantity(int productId, int locationId, int quantity); // ���ٿ��
    int getTotalQuantityByProduct(int productId);  // ĳ����Ʒ���ܿ��
    int getTotalQuantityByWarehouse(int warehouseId); // ĳ���ֿ���ܿ��
    List<Inventory> searchWithConditions(Integer productId, Integer warehouseId, Integer locationId, Integer minQuantity, Integer maxQuantity);
}