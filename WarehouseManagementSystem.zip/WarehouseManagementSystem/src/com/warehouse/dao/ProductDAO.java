package com.warehouse.dao;

import com.warehouse.beans.Product;
import java.util.List;

public interface ProductDAO extends BaseDAO<Product> {
    // ��Ʒ���еĲ���
    Product getBySku(String sku);
    List<Product> getByCategory(String category);
    List<Product> search(String keyword);  // �����ƻ�SKU����
    List<Product> getLowStockProducts();   // ��ȡ�Ϳ���Ʒ�����ܰ�ȫ��棩
    List<Product> getActiveProducts();
    boolean deactivateProduct(int productId);
    boolean activateProduct(int productId);
    List<Product> getByPageWithKeyword(int pageNum, int pageSize, String keyword, String category);
    int getCountWithKeyword(String keyword, String category);
}