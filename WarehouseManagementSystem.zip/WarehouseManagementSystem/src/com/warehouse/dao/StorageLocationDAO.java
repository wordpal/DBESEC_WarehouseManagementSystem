package com.warehouse.dao;

import com.warehouse.beans.StorageLocation;
import java.util.List;

public interface StorageLocationDAO extends BaseDAO<StorageLocation> {
    // ��λ���еĲ���
    StorageLocation getByCode(String locationCode);
    List<StorageLocation> getByWarehouse(int warehouseId);
    List<StorageLocation> getAvailableLocations(int warehouseId);  // ���л�λ
    List<StorageLocation> getOccupiedLocations(int warehouseId);   // ռ�û�λ
    boolean updateStatus(int locationId, int status);  // ���»�λ״̬
    List<StorageLocation> getByPageWithWarehouse(int pageNum, int pageSize, Integer warehouseId, Integer status);
    int getCountWithWarehouse(Integer warehouseId, Integer status);
}