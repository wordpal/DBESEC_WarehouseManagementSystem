package com.warehouse.util;

import java.sql.*;

public class DatabaseUtil {
    private static final String URL = "jdbc:mysql://localhost:3306/warehouse_ms?useUnicode=true&characterEncoding=utf8&useSSL=false&serverTimezone=Asia/Shanghai&allowPublicKeyRetrieval=true";
    private static final String USER = "root";
    private static final String PASSWORD = "050320";  // ���MySQL����
    
    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("MySQL�������سɹ���");
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL��������ʧ�ܣ�");
            e.printStackTrace();
        }
    }
    
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
    
    public static void close(Connection conn, Statement stmt, ResultSet rs) {
        try {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    // �������ݿ�����
    public static void testConnection() {
        Connection conn = null;
        try {
            conn = getConnection();
            System.out.println("���ݿ����Ӳ��Գɹ���");
        } catch (SQLException e) {
            System.out.println("���ݿ����Ӳ���ʧ�ܣ�" + e.getMessage());
            e.printStackTrace();
        } finally {
            close(conn, null, null);
        }
    }
}