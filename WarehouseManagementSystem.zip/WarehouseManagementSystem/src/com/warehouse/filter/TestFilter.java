package com.warehouse.filter;

import javax.servlet.*;
import java.io.IOException;

public class TestFilter implements Filter {
    
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        System.out.println("=== ���Թ�������ʼ�� ===");
    }
    
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) 
            throws IOException, ServletException {
        System.out.println("=== ���Թ�����ִ�� ===");
        System.out.println("�������ǰ��" + request.getCharacterEncoding());
        
        // ǿ�����ñ���
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        
        System.out.println("��������" + request.getCharacterEncoding());
        
        chain.doFilter(request, response);
    }
    
    @Override
    public void destroy() {
    }
}